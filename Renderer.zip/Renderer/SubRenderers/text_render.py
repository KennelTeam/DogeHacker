
from PyQt5.QtWidgets import QWidget, QLabel
from PyQt5.QtGui import QFontMetrics, QFont, QPaintEvent
import xml.etree.ElementTree as ET

class ColoredText(QWidget):

    padding = 15

    def __init__(self, data: ET.Element):
        super().__init__()
        self.data = data
        self.initUI(data)

    def initUI(self, data: ET.Element):
        cur_y = 0
        cur_x = 0
        font = QFont("Courier", 15)
        fm = QFontMetrics(font)
        # print(self.window().width(), self.width())
        for child in data:
            if child.tag == "enter":
                cur_x = 0
                cur_y += fm.height()
                continue
            # print("width", self.width())
            for word in child.text.split():
                if cur_x + fm.width(word) > self.width():
                    cur_x = 0
                    cur_y += fm.height()
                label = QLabel(word, self)
                label.setFont(font)
                # print(child.attrib["color"])
                label.setStyleSheet("color:" + child.attrib["color"])
                label.move(cur_x, cur_y)
                cur_x += fm.width(word + " ")

        # print(fm.height(), fm.width("widthwidth"), fm.widthChar("w"))
        self.setMinimumHeight(cur_y + fm.height())
        self.show()

    def paintEvent(self, a0: QPaintEvent):
        print("change width", self.width())
        # self.initUI(self.data)

